<?php

function smarty_function_url($args, &$smarty) {
	return ps_url_wrapper($args);
}

?>
