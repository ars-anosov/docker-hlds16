<?php
/**
	Creates a non-image dual percentage bar with defined width and color. 
**/
function smarty_function_dualbar($args, &$smarty)
{
	return dual_bar($args);
}

?>
