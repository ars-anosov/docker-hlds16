Directory: PS/Skill

This directory contains custom skill calculation functions. This allows any 
user to create new custom skill calcultions w/o having to modify any existing 
code. Use an existing skill function as a guideline. To use a custom skill 
function configure the base name of the function under the configuration 
variable 'Skill Calculation' in the main section of the Admin Control Panel 
(ACP).


