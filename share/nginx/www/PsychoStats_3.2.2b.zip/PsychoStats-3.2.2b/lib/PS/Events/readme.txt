Directory: PS/Events

This directory contains custom event functions. This allows any user to create 
new custom event handlers w/o having to modify any existing code. Use an 
existing event function as a guideline. The event and it's regular expression 
for matching it must be defined in the Events configuration of the Admin 
Control Panel (ACP).
